<template>
    <div>
        Cart

    </div>
</template>

<script>
export default {
    name:'Cart'
}
</script>