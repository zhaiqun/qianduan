<template>
    <div>
        news
    </div>
</template>