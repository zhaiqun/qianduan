const fs = require('fs')

function fromJsonFile(fileName) {
    return (req, res) => {

        const data = fs.readFileSync(`mocker/data/${fileName}.json`).toString()
        const json = JSON.parse(data)
        return res.json(json)
    }

}

const prox = {
    'GET /api/getSwape': fromJsonFile('banner'),
    'GET /api/getNavPic': fromJsonFile('navPic')
}

module.exports = prox