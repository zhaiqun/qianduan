<template>
    <div>
        Cart

<br>
<br>
<p></p>
        CartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCartCart
    </div>
</template>

<script>
export default {
    name:'Cart'
}
</script>