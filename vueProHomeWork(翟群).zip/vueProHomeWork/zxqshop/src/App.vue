<template>
<div  class='containner'>
<mt-header fixed title="固定在顶部"></mt-header>
<router-view></router-view>
<mt-tabbar fixed >  <mt-tab-item id="外卖">
  <!-- <router-link to='/index' > -->
    首页 
    <img slot="icon" src="./assets/index.png">


  <!-- </router-link>   -->
  </mt-tab-item>
   
  <mt-tab-item id="订单">
     <!-- <router-link to='/order' > -->
    <img slot="icon" src="./assets/goodsShow.png">
    订单 
    <!-- </router-link> -->
  </mt-tab-item>
   
       
  <mt-tab-item id="发现">
    <!-- <router-link to='/cart' >   -->
    购物车  
    <img slot="icon" src="./assets/shopcart.png">
 <!-- </router-link> -->
  </mt-tab-item>
  
          
  <mt-tab-item id="我的">    
    <!-- <router-link to='/vip' > -->
    <img slot="icon" src="./assets/vip.png">
    我的
    <!-- </router-link> -->
  </mt-tab-item>
        
</mt-tabbar>
</div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style >

*{
  margin: 0;
  padding: 0;
  box-sizing: border-box
}
.containner{

    width: 100%;
    padding-top: 40px;
  	padding-bottom: 50px;
}
</style>

