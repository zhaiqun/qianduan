import  React  from  'react'
import { Pagination   } from 'antd';
export   default class  extends  React.Component{
    constructor(){
        super()
    }
    render(){

        return  <div>
        <Pagination
          showSizeChanger
          onShowSizeChange={(c)=>{console.log(c)}}
          defaultCurrent={3}
          total={500}
        />
        <br />
        <Pagination
          showSizeChanger
          onShowSizeChange={(c)=>{console.log(c)}}
          defaultCurrent={3}
          total={500}
          disabled
        />
      </div>


    }

}  