import   React   from  'react'

export  default  class  About  extends  React.Component{
    constructor(){
        super()
    }
    render(){

        return  <div>
            About
        </div>
    }

}